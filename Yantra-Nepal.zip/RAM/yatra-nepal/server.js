const express = require('express');
const path = require('path');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');

const app = express();
app.use(cors());
app.use(express.json());

// Serve static files from 'frontend' folder
app.use(express.static(path.join(__dirname, 'frontend')));

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

const PORT = 5000;

// In-memory storage for bus info keyed by busId
const buses = {};

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  // Drivers emit 'driverUpdate' with bus data & location
  socket.on('driverUpdate', (data) => {
    if (
      !data.busId ||
      !data.location ||
      typeof data.location.lat !== 'number' ||
      typeof data.location.lng !== 'number'
    ) {
      console.warn('Invalid driverUpdate data:', data);
      return;
    }

    // Update or add bus info
    buses[data.busId] = {
      location: data.location,
      loadStatus: data.loadStatus || 'green',
      from: data.from || 'Unknown',
      to: data.to || 'Unknown',
      driverName: data.driverName || 'Unknown',
      busNo: data.busNo || 'Unknown',
      lastUpdate: Date.now(),
    };

    // Broadcast updated bus info to all clients
    io.emit('busUpdate', { busId: data.busId, ...buses[data.busId] });
  });

  // When client requests all buses, send current info for all
  socket.on('requestAllBuses', () => {
    Object.entries(buses).forEach(([busId, busData]) => {
      socket.emit('busUpdate', { busId, ...busData });
    });
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// Serve passenger.html by default
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'passenger.html'));
});

// You can add explicit routes for driver and tracking pages if you want:
// app.get('/driver', (req, res) => res.sendFile(path.join(__dirname, 'frontend', 'driver.html')));
// app.get('/tracking', (req, res) => res.sendFile(path.join(__dirname, 'frontend', 'tracking.html')));

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
