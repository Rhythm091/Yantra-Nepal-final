// Connect to Socket.IO server (adjust URL if needed)
const socket = io('http://localhost:5000');

// DOM elements
const startBtn = document.getElementById('startBtn');
const busIdInput = document.getElementById('busIdInput');
const busNoInput = document.getElementById('busNoInput');
const driverNameInput = document.getElementById('driverNameInput');
const fromInput = document.getElementById('fromInput');
const toInput = document.getElementById('toInput');
const loadButtons = document.querySelectorAll('.load-btn');
const loadStatusDisplay = document.getElementById('current-load');

let currentLoad = 'green'; // Default load status
let busLocation = [27.7172, 85.3240]; // Kathmandu default location
let map, busMarker;

// Create Leaflet icon for bus based on load color
function createBusIcon(color) {
  return L.icon({
    iconUrl: 'images/bus-line.png',
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -38],
    className: `bus-icon-${color}`
  });
}

// Update load status display text and button styling
function updateLoadDisplay(newLoad) {
  currentLoad = newLoad;
  const loadTextMap = { green: 'Low', yellow: 'Medium', red: 'Full' };
  loadStatusDisplay.textContent = loadTextMap[newLoad] || 'Unknown';

  // Highlight selected button
  loadButtons.forEach(btn => {
    btn.classList.toggle('selected', btn.getAttribute('data-status') === newLoad);
  });
}

// Initialize Leaflet map and add marker
function initMap() {
  map = L.map('map').setView(busLocation, 13);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  busMarker = L.marker(busLocation, { icon: createBusIcon(currentLoad) }).addTo(map);
}

// Update marker position and popup on map
function updateMapMarker(location, busInfo) {
  busLocation = location;
  busMarker.setLatLng(location);
  busMarker.setIcon(createBusIcon(currentLoad));

  const popupContent = `
    <b>Bus No:</b> ${busInfo.busNo}<br/>
    <b>Driver:</b> ${busInfo.driverName}<br/>
    <b>Route:</b> ${busInfo.from} → ${busInfo.to}<br/>
    <b>Load:</b> ${loadStatusDisplay.textContent}
  `;
  busMarker.bindPopup(popupContent).openPopup();
  map.setView(location, 15);
}

// Send bus update to server
function sendBusUpdate(busInfo, location) {
  if (!busInfo.busId) return;

  socket.emit('driverUpdate', {  // <-- use 'driverUpdate' event to match backend
    busId: busInfo.busId,
    busNo: busInfo.busNo,
    driverName: busInfo.driverName,
    from: busInfo.from,
    to: busInfo.to,
    location: {
      lat: location[0],
      lng: location[1]
    },
    loadStatus: currentLoad
  });
}

socket.on('driverUpdate', (data) => {
  console.log('Received driverUpdate:', data); // Add this line for debugging
});


// Start tracking location and send updates every position change
function startTracking(busInfo) {
  if (!navigator.geolocation) {
    alert('Geolocation is not supported by your browser.');
    return;
  }

  navigator.geolocation.getCurrentPosition(position => {
    busLocation = [position.coords.latitude, position.coords.longitude];
    initMap();
    updateMapMarker(busLocation, busInfo);
    sendBusUpdate(busInfo, busLocation);
  }, err => {
    alert('Failed to get your location. Please allow location access.');
  });

  navigator.geolocation.watchPosition(position => {
    busLocation = [position.coords.latitude, position.coords.longitude];
    updateMapMarker(busLocation, busInfo);
    sendBusUpdate(busInfo, busLocation);
  }, err => {
    console.warn('Geolocation watch error:', err);
  }, {
    enableHighAccuracy: true,
    maximumAge: 10000,
    timeout: 5000
  });
}

// Load saved data from localStorage if available
function loadSavedBusData() {
  const savedBusId = localStorage.getItem('busId');
  if (!savedBusId) return null;

  return {
    busId: savedBusId,
    busNo: localStorage.getItem('busNo') || '',
    driverName: localStorage.getItem('driverName') || '',
    from: localStorage.getItem('fromLocation') || '',
    to: localStorage.getItem('toLocation') || '',
    loadStatus: localStorage.getItem('loadStatus') || 'green'
  };
}

// Save bus data to localStorage
function saveBusData(busInfo) {
  localStorage.setItem('busId', busInfo.busId);
  localStorage.setItem('busNo', busInfo.busNo);
  localStorage.setItem('driverName', busInfo.driverName);
  localStorage.setItem('fromLocation', busInfo.from);
  localStorage.setItem('toLocation', busInfo.to);
  localStorage.setItem('loadStatus', currentLoad);
}

// Event Listeners setup
document.addEventListener('DOMContentLoaded', () => {
  // Load saved data to form if any
  const savedData = loadSavedBusData();
  if (savedData) {
    busIdInput.value = savedData.busId;
    busNoInput.value = savedData.busNo;
    driverNameInput.value = savedData.driverName;
    fromInput.value = savedData.from;
    toInput.value = savedData.to;
    updateLoadDisplay(savedData.loadStatus);
  } else {
    updateLoadDisplay(currentLoad); // default
  }

  // Load status buttons click
  loadButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      updateLoadDisplay(btn.getAttribute('data-status'));
    });
  });

  // Start tracking button
  startBtn.addEventListener('click', () => {
    const busId = busIdInput.value.trim();
    const busNo = busNoInput.value.trim();
    const driverName = driverNameInput.value.trim();
    const from = fromInput.value.trim();
    const to = toInput.value.trim();

    if (!busId || !busNo || !driverName || !from || !to) {
      alert('Please fill in all fields.');
      return;
    }

    const busInfo = { busId, busNo, driverName, from, to };
    startTracking(busInfo);
  });
});
