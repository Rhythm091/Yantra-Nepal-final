  async function translateText(text, targetLang) {
    if (targetLang === "en") return text; // Don't translate to English via API

    try {
      const langPair = `en|${targetLang}`;
      const response = await fetch(
        `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${langPair}`
      );
      const data = await response.json();
      return data.responseData.translatedText || text;
    } catch (error) {
      console.error("Translation failed:", error);
      return text;
    }
  }

  async function translatePage(lang) {
    const elements = document.querySelectorAll(".translatable");

    for (const el of elements) {
      const originalText = el.getAttribute("data-original") || el.textContent.trim();

      // Save original English if not already stored
      if (!el.hasAttribute("data-original")) {
        el.setAttribute("data-original", originalText);
      }

      if (lang === "en") {
        el.textContent = el.getAttribute("data-original"); // Restore original English
      } else {
        const translated = await translateText(originalText, lang);
        el.textContent = translated;
      }
    }
  }