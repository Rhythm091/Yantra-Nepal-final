const socket = io('http://localhost:5000');

const map = L.map('map').setView([27.7, 85.3], 13); // Kathmandu approx

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution:
    '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

let busMarker = null;
const busStatusEl = document.getElementById('bus-status');

socket.on('busLocationUpdate', (data) => {
  if (busMarker) {
    busMarker.setLatLng([data.lat, data.lon]);
  } else {
    busMarker = L.marker([data.lat, data.lon]).addTo(map);
  }
});

socket.on('busLoadStatusUpdate', (data) => {
  // Update bus load status badge
  const load = data.load;
  busStatusEl.textContent = load.toUpperCase();
  busStatusEl.className = 'badge'; // reset classes
  if (load === 'green') {
    busStatusEl.classList.add('green');
  } else if (load === 'yellow') {
    busStatusEl.classList.add('yellow');
  } else if (load === 'red') {
    busStatusEl.classList.add('red');
  } else {
    busStatusEl.textContent = 'UNKNOWN';
  }
});
