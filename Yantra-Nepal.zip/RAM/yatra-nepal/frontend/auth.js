document.addEventListener("DOMContentLoaded", () => {
  const authLink = document.getElementById("auth-link");

  function isLoggedIn() {
    return !!localStorage.getItem("loggedInUser");
  }

  function updateNavbar() {
    if (!authLink) return;
    if (isLoggedIn()) {
      authLink.innerHTML = `<a href="#" id="logoutLink">Logout</a>`;
      document.getElementById("logoutLink").addEventListener("click", (e) => {
        e.preventDefault();
        localStorage.removeItem("loggedInUser");
        updateNavbar();
        window.location.href = "main.html";  // redirect to login page after logout
      });
    } else {
      authLink.innerHTML = `<a href="index.html">Login</a>`;
    }
  }

  updateNavbar();

  // Login Form handling (only on login page)
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const phone = document.getElementById("Number").value.trim();
      const password = document.getElementById("password").value.trim();
      const storedUser = JSON.parse(localStorage.getItem(`user-${phone}`));

      if (storedUser && storedUser.password === password) {
        localStorage.setItem("loggedInUser", phone);
        window.location.href = "main.html"; // redirect after successful login
      } else {
        document.getElementById("errorMsg").textContent = "Invalid phone or password.";
      }
    });
  }

  // Register Form handling (only on register page)
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    registerForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const fullname = document.getElementById("fullname").value.trim();
      const email = document.getElementById("email").value.trim();
      const phone = document.getElementById("phone").value.trim();
      const password = document.getElementById("password").value.trim();
      const confirmPassword = document.getElementById("confirmPassword").value.trim();

      if (!fullname || !email || !phone || !password || !confirmPassword) {
        alert("Please fill in all fields.");
        return;
      }

      if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return;
      }

      const user = { fullname, email, phone, password };
      localStorage.setItem(`user-${phone}`, JSON.stringify(user));
      window.location.href = "index.html";
    });
  }
});
