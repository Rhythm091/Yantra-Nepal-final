const stars = document.querySelectorAll("#starRating span");
const feedbackText = document.getElementById("feedbackText");
const submitBtn = document.getElementById("submitFeedback");

let selectedRating = 0;

// Star click event
stars.forEach(star => {
  star.addEventListener("click", () => {
    selectedRating = star.getAttribute("data-value");

    // Update star colors
    stars.forEach(s => {
      s.classList.remove("active");
      if (s.getAttribute("data-value") <= selectedRating) {
        s.classList.add("active");
      }
    });
  });
});

// Save feedback and redirect to home page
submitBtn.addEventListener("click", () => {
  const feedback = feedbackText.value.trim();

  if (selectedRating === 0) {
    alert("Please select a star rating!");
    return;
  }

  if (feedback === "") {
    alert("Please write your feedback!");
    return;
  }

  // Save to localStorage
  const feedbackData = {
    rating: selectedRating,
    feedback: feedback,
    date: new Date().toLocaleString()
  };

  localStorage.setItem("userFeedback", JSON.stringify(feedbackData));
  alert("Thank you! Your feedback has been saved.");

  // Redirect to home page after 1 second
  setTimeout(() => {
    window.location.href = "main.html"; // Change to your home page name
  }, 1000);
});
