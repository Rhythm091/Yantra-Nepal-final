// Connect to Socket.IO server
const socket = io('http://localhost:5000');

// Initialize map centered on Kathmandu
const map = L.map('map').setView([27.7, 85.3], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors'
}).addTo(map);

const busMarkers = {};
const busDataStore = {};

// DOM Elements for info display
const busFilter = document.getElementById('busFilter');
const loadStatusElem = document.getElementById('loadStatus');
const routeInfoElem = document.getElementById('routeInfo');
const driverNameElem = document.getElementById('driverName');
const busNoElem = document.getElementById('busNo');

// Create custom bus icon with load color
function createBusIcon(color) {
  return L.icon({
    iconUrl: 'images/bus-line.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
    className: `bus-icon-${color}`
  });
}

// Update the details section below map for selected bus
function updateInfoDisplay(busId) {
  if (busId === 'all' || !busDataStore[busId]) {
    loadStatusElem.textContent = 'N/A';
    routeInfoElem.textContent = 'Route: N/A';
    driverNameElem.textContent = 'Driver: N/A';
    busNoElem.textContent = 'Bus No: N/A';
    return;
  }
  const bus = busDataStore[busId];
  loadStatusElem.textContent = bus.loadStatus.charAt(0).toUpperCase() + bus.loadStatus.slice(1);
  routeInfoElem.textContent = `Route: ${bus.from || 'Unknown'} → ${bus.to || 'Unknown'}`;
  driverNameElem.textContent = `Driver: ${bus.driverName || 'Unknown'}`;
  busNoElem.textContent = `Bus No: ${bus.busNo || 'Unknown'}`;
}

// Add new bus to the filter dropdown if not present
function addBusOption(busId) {
  if (!Array.from(busFilter.options).some(opt => opt.value === busId)) {
    const option = document.createElement('option');
    option.value = busId;
    option.textContent = busId;
    busFilter.appendChild(option);
  }
}

// Show or hide markers depending on filter
function updateMarkersVisibility() {
  const filterVal = busFilter.value;
  Object.entries(busMarkers).forEach(([busId, marker]) => {
    if (filterVal === 'all' || filterVal === busId) {
      marker.addTo(map);
      if (filterVal === busId) {
        map.panTo(marker.getLatLng());
      }
    } else {
      map.removeLayer(marker);
    }
  });
}

// When connected, ask server for all buses to get initial data
socket.on('connect', () => {
  socket.emit('requestAllBuses');
});

// On receiving bus updates
socket.on('busUpdate', (data) => {
  if (!data.busId || !data.location || !data.loadStatus) return;

  busDataStore[data.busId] = data;

  addBusOption(data.busId);

  const popupContent = `
    <b>Bus ID:</b> ${data.busId}<br/>
    <b>Bus Number:</b> ${data.busNo || 'Unknown'}<br/>
    <b>Driver Name:</b> ${data.driverName || 'Unknown'}<br/>
    <b>Load:</b> ${data.loadStatus.charAt(0).toUpperCase() + data.loadStatus.slice(1)}<br/>
    <b>Route:</b> ${data.from || 'Unknown'} → ${data.to || 'Unknown'}
  `;

  if (!busMarkers[data.busId]) {
    busMarkers[data.busId] = L.marker([data.location.lat, data.location.lng], {
      icon: createBusIcon(data.loadStatus)
    }).addTo(map);
    busMarkers[data.busId].bindPopup(popupContent);
  } else {
    busMarkers[data.busId].setLatLng([data.location.lat, data.location.lng]);
    busMarkers[data.busId].getPopup().setContent(popupContent);
    busMarkers[data.busId].setIcon(createBusIcon(data.loadStatus));
  }

  if (busFilter.value === data.busId) {
    updateInfoDisplay(data.busId);
  }

  updateMarkersVisibility();
});

// Filter change event handler
busFilter.addEventListener('change', () => {
  updateMarkersVisibility();
  updateInfoDisplay(busFilter.value);
});

// Initialize filter and info display
busFilter.value = 'all';
updateInfoDisplay('all');
