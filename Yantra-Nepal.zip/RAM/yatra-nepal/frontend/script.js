const hamburger = document.getElementById("hamburger");
const navMenu = document.querySelector('.navbar');
const navLinks = document.querySelectorAll('.nav-links li a');

hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('menu-open');
});

navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('menu-open'); // fixed: use navMenu not navbar
    });
});

// Seat selection logic
const seats = document.querySelectorAll('.seat');
const selectedList = document.getElementById('selected-seats-list');
const modal = document.getElementById('successModal');

seats.forEach(seat => {
    seat.addEventListener('click', () => {
        if (seat.classList.contains('booked')) return;
        seat.classList.toggle('selected');
        updateSelectedSeats();
    });
});

function updateSelectedSeats() {
    const selected = document.querySelectorAll('.seat.selected span');
    const names = Array.from(selected).map(s => s.textContent);
    selectedList.textContent = names.join(', ');
}

function showModal() {
    if (selectedList.textContent !== '') {
        modal.classList.add('show');
    }
}

function hideModal() {
    modal.classList.remove('show');
}
